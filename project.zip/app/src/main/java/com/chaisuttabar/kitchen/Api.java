package com.chaisuttabar.kitchen;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.LinkedHashSet;

/** Talks to Supabase (same project as the website) and stores the login. */
final class Api {
    static final String SB_URL = "https://ubgukaaahkoacuswwhmj.supabase.co";
    static final String SB_KEY = "sb_publishable_1VdDtAm6maETXboWuRZYIQ_TzVXk8j6";
    static final String EMAIL_DOMAIN = "@chaisuttabar.app";

    static class HttpException extends IOException {
        final int code;
        HttpException(int code, String msg) {
            super("HTTP " + code + " " + msg);
            this.code = code;
        }
    }

    /** Thrown when the login is wrong or expired. */
    static class AuthException extends IOException {
        AuthException() {
            super("auth");
        }
    }

    private final SharedPreferences sp;

    Api(Context c) {
        sp = c.getSharedPreferences("kitchen", Context.MODE_PRIVATE);
    }

    // ---------- login storage ----------
    boolean hasLogin() {
        return !sp.getString("refresh", "").isEmpty();
    }

    void logout() {
        sp.edit().remove("access").remove("refresh").apply();
    }

    private void saveTokens(String json) throws JSONException {
        JSONObject o = new JSONObject(json);
        sp.edit()
                .putString("access", o.getString("access_token"))
                .putString("refresh", o.getString("refresh_token"))
                .apply();
    }

    // ---------- voice language: hi, en or both ----------
    String voice() {
        return sp.getString("voice", "hi");
    }

    void setVoice(String v) {
        sp.edit().putString("voice", v).apply();
    }

    String siteUrl() {
        return sp.getString("site", "");
    }

    void setSiteUrl(String u) {
        sp.edit().putString("site", u).apply();
    }

    int voiceIdx(String lang) {
        return sp.getInt("vi_" + lang, 0);
    }

    void setVoiceIdx(String lang, int i) {
        sp.edit().putInt("vi_" + lang, i).apply();
    }

    boolean wide() {
        return sp.getBoolean("wide", true);
    }

    void setWide(boolean w) {
        sp.edit().putBoolean("wide", w).apply();
    }

    // ---------- seen orders (so each order is spoken once) ----------
    boolean seeded() {
        return sp.getBoolean("seeded", false);
    }

    void setSeeded() {
        sp.edit().putBoolean("seeded", true).apply();
    }

    LinkedHashSet<String> loadSeen() {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        String s = sp.getString("seen", "");
        if (!s.isEmpty()) {
            for (String x : s.split(",")) {
                if (!x.isEmpty()) set.add(x);
            }
        }
        return set;
    }

    void saveSeen(LinkedHashSet<String> set) {
        while (set.size() > 500) {
            Iterator<String> it = set.iterator();
            it.next();
            it.remove();
        }
        sp.edit().putString("seen", TextUtils.join(",", set)).apply();
    }

    // ---------- http ----------
    private static String read(InputStream in) throws IOException {
        if (in == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toString("UTF-8");
    }

    private static void setMethod(HttpURLConnection c, String method) throws IOException {
        try {
            c.setRequestMethod(method);
        } catch (ProtocolException e) {
            try {
                Field f = HttpURLConnection.class.getDeclaredField("method");
                f.setAccessible(true);
                f.set(c, method);
            } catch (Exception e2) {
                throw e;
            }
        }
    }

    private static String http(String method, String url, String body, String bearer, String prefer) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        setMethod(c, method);
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestProperty("apikey", SB_KEY);
        c.setRequestProperty("Content-Type", "application/json");
        if (bearer != null) c.setRequestProperty("Authorization", "Bearer " + bearer);
        if (prefer != null) c.setRequestProperty("Prefer", prefer);
        if (body != null) {
            c.setDoOutput(true);
            OutputStream o = c.getOutputStream();
            o.write(body.getBytes(StandardCharsets.UTF_8));
            o.close();
        }
        int code = c.getResponseCode();
        String text = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
        c.disconnect();
        if (code == 401) throw new AuthException();
        if (code >= 400) throw new HttpException(code, text);
        return text;
    }

    // ---------- calls ----------
    void login(String id, String password) throws IOException {
        String email = id.contains("@") ? id : id + EMAIL_DOMAIN;
        try {
            JSONObject b = new JSONObject();
            b.put("email", email);
            b.put("password", password);
            String r = http("POST", SB_URL + "/auth/v1/token?grant_type=password", b.toString(), null, null);
            saveTokens(r);
        } catch (HttpException e) {
            if (e.code == 400 || e.code == 422) throw new AuthException();
            throw e;
        } catch (JSONException e) {
            throw new IOException("bad response");
        }
    }

    private boolean refresh() {
        String rt = sp.getString("refresh", "");
        if (rt.isEmpty()) return false;
        try {
            JSONObject b = new JSONObject();
            b.put("refresh_token", rt);
            String r = http("POST", SB_URL + "/auth/v1/token?grant_type=refresh_token", b.toString(), null, null);
            saveTokens(r);
            return true;
        } catch (HttpException e) {
            if (e.code == 400 || e.code == 422) logout();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    JSONArray orders() throws IOException {
        for (int attempt = 0; attempt < 2; attempt++) {
            try {
                String tok = sp.getString("access", "");
                String r = http("GET", SB_URL + "/rest/v1/csb_orders?select=*&order=created_at.desc&limit=100", null, tok, null);
                return new JSONArray(r);
            } catch (AuthException e) {
                if (attempt == 1 || !refresh()) throw new AuthException();
            } catch (JSONException e) {
                throw new IOException("bad response");
            }
        }
        throw new AuthException();
    }

    /** All orders created between two ISO times (used for the monthly sales report). */
    JSONArray ordersBetween(String fromIso, String toIso) throws IOException {
        JSONArray all = new JSONArray();
        for (int offset = 0; offset < 20000; offset += 1000) {
            JSONArray page = null;
            for (int attempt = 0; attempt < 2 && page == null; attempt++) {
                try {
                    String tok = sp.getString("access", "");
                    String url = SB_URL + "/rest/v1/csb_orders?select=created_at,total,table_no,customer_name,lines"
                            + "&created_at=gte." + URLEncoder.encode(fromIso, "UTF-8")
                            + "&created_at=lt." + URLEncoder.encode(toIso, "UTF-8")
                            + "&order=created_at.asc&limit=1000&offset=" + offset;
                    page = new JSONArray(http("GET", url, null, tok, null));
                } catch (AuthException e) {
                    if (attempt == 1 || !refresh()) throw new AuthException();
                } catch (JSONException e) {
                    throw new IOException("bad response");
                }
            }
            if (page == null) throw new AuthException();
            for (int i = 0; i < page.length(); i++) all.put(page.opt(i));
            if (page.length() < 1000) break;
        }
        return all;
    }

    void done(String id) throws IOException {
        for (int attempt = 0; attempt < 2; attempt++) {
            try {
                String tok = sp.getString("access", "");
                http("PATCH", SB_URL + "/rest/v1/csb_orders?id=eq." + URLEncoder.encode(id, "UTF-8"),
                        "{\"status\":\"done\"}", tok, "return=minimal");
                return;
            } catch (AuthException e) {
                if (attempt == 1 || !refresh()) throw new AuthException();
            }
        }
    }
}
