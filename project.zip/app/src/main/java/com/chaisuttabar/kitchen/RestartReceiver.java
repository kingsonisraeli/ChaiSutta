package com.chaisuttabar.kitchen;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restarts the order service after reboot, update, or if the phone killed it. */
public class RestartReceiver extends BroadcastReceiver {
    static final String ACTION_WATCHDOG = "com.chaisuttabar.kitchen.WATCHDOG";

    @Override
    public void onReceive(Context c, Intent intent) {
        try {
            if (new Api(c).hasLogin()) {
                c.startForegroundService(new Intent(c, OrderService.class));
            }
        } catch (Exception e) {
            // the phone refused a background start; the next alarm will try again
        }
    }

    /** Wakes the app in delayMs milliseconds to make sure the service is running. */
    static void schedule(Context c, long delayMs) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(c, RestartReceiver.class).setAction(ACTION_WATCHDOG);
            PendingIntent pi = PendingIntent.getBroadcast(c, 7, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delayMs, pi);
        } catch (Exception e) {
            // ignore
        }
    }
}
