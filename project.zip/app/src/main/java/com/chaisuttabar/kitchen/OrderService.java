package com.chaisuttabar.kitchen;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.LinkedHashSet;
import java.util.Locale;

/** Foreground service: keeps listening for new orders and speaks them, even with the screen off. */
public class OrderService extends Service implements TextToSpeech.OnInitListener {
    static final String ACTION_REPEAT = "com.chaisuttabar.kitchen.REPEAT";
    static final String ACTION_TEST = "com.chaisuttabar.kitchen.TEST";
    static final String CHANNEL = "kitchen_orders";
    static final String CHANNEL_ORDERS = "new_orders";
    static final int NOTIF_ID = 1;

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private static class Item {
        final String text;
        final String lang;

        Item(String text, String lang) {
            this.text = text;
            this.lang = lang;
        }
    }

    private final ArrayDeque<Item> queue = new ArrayDeque<>();
    private boolean speaking = false;
    private long speakStart = 0;
    private volatile boolean running = false;
    private Thread poller;
    private PowerManager.WakeLock wakeLock;
    private Api api;
    private String lastNotifText = "";

    @Override
    public void onCreate() {
        super.onCreate();
        api = new Api(this);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Kitchen orders", NotificationManager.IMPORTANCE_LOW);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(ch);
        NotificationChannel orderCh = new NotificationChannel(CHANNEL_ORDERS, "New orders", NotificationManager.IMPORTANCE_HIGH);
        orderCh.enableVibration(true);
        nm.createNotificationChannel(orderCh);
        tts = new TextToSpeech(this, this);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kitchen:orders");
        wakeLock.acquire();
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) return;
        tts.setSpeechRate(0.9f);
        tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build());
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
            }

            @Override
            public void onDone(String utteranceId) {
                finished();
            }

            @Override
            public void onError(String utteranceId) {
                finished();
            }
        });
        synchronized (queue) {
            ttsReady = true;
        }
        pump();
    }

    private void finished() {
        synchronized (queue) {
            speaking = false;
        }
        pump();
    }

    private void enqueue(String text, String lang) {
        if (text == null || text.trim().isEmpty()) return;
        synchronized (queue) {
            queue.add(new Item(text, lang));
        }
        pump();
    }

    /** Speaks the next waiting sentence, one at a time, each in its own language. */
    private void pump() {
        Item it;
        synchronized (queue) {
            if (!ttsReady || speaking || queue.isEmpty()) return;
            it = queue.poll();
            speaking = true;
            speakStart = System.currentTimeMillis();
        }
        boolean en = "en".equals(it.lang);
        int r = tts.setLanguage(en ? new Locale("en", "IN") : new Locale("hi", "IN"));
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(en ? Locale.ENGLISH : Locale.getDefault());
        }
        int sr = tts.speak(it.text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime());
        if (sr != TextToSpeech.SUCCESS) finished();
    }

    /** Speaks an order in the language chosen in the app: Hindi, English or both. */
    private void announce(JSONObject o) {
        String mode = api.voice();
        if (!"en".equals(mode)) enqueue(o.optString("say", ""), "hi");
        if (!"hi".equals(mode)) enqueue(englishText(o), "en");
    }

    private String englishText(JSONObject o) {
        String table = o.optString("table_no", "");
        if ("null".equals(table)) table = "";
        String name = o.optString("customer_name", "");
        if ("null".equals(name)) name = "";
        StringBuilder sb = new StringBuilder();
        sb.append(!table.isEmpty() ? "Table number " + table + ". " : "WhatsApp order. ");
        if (!name.isEmpty()) sb.append(name).append("'s order. ");
        JSONArray lines = o.optJSONArray("lines");
        if (lines != null) {
            for (int j = 0; j < lines.length(); j++) {
                String l = String.valueOf(lines.opt(j)).split(" \\| ")[0];
                l = l.replace("\u00D7", " ").replace("(R)", "regular").replace("(L)", "large")
                        .replace(" - ", ", ").replaceAll("\\s+", " ").trim();
                sb.append(l).append(". ");
            }
        }
        return sb.toString();
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Chai Sutta Bar Kitchen")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void showNotification(String text) {
        lastNotifText = text;
        Notification n = buildNotification(text);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void updateNotification(String text) {
        lastNotifText = text;
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                .notify(NOTIF_ID, buildNotification(text));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        showNotification("Listening for orders - voice ON");
        if (intent != null && ACTION_TEST.equals(intent.getAction())) {
            String mode = api.voice();
            if (!"en".equals(mode)) enqueue("\u0915\u093F\u091A\u0928 \u0935\u0949\u0907\u0938 \u0905\u0932\u0930\u094D\u091F \u091A\u093E\u0932\u0942 \u0939\u094B \u0917\u092F\u093E", "hi");
            if (!"hi".equals(mode)) enqueue("Kitchen voice alerts are on", "en");
        }
        if (intent != null && ACTION_REPEAT.equals(intent.getAction())) {
            try {
                announce(new JSONObject(intent.getStringExtra("text")));
            } catch (Exception e) {
                // ignore a bad request
            }
        }
        if (!running) {
            running = true;
            poller = new Thread(this::loop, "order-poller");
            poller.start();
        }
        return START_STICKY;
    }

    private void loop() {
        while (running) {
            synchronized (queue) {
                if (speaking && System.currentTimeMillis() - speakStart > 30000) speaking = false;
            }
            pump();
            try {
                JSONArray arr = api.orders();
                handle(arr);
                if (!"Listening for orders - voice ON".equals(lastNotifText)) {
                    updateNotification("Listening for orders - voice ON");
                }
            } catch (Api.AuthException e) {
                if (!"Login needed - open the app".equals(lastNotifText)) {
                    updateNotification("Login needed - open the app");
                }
            } catch (Exception e) {
                // network problem: try again on the next round
            }
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    private void handle(JSONArray arr) {
        LinkedHashSet<String> seen = api.loadSeen();
        boolean first = !api.seeded();
        for (int i = arr.length() - 1; i >= 0; i--) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String id = o.optString("id", "");
            if (id.isEmpty() || seen.contains(id)) continue;
            seen.add(id);
            if (!first && !"done".equals(o.optString("status"))) {
                announce(o);
                notifyOrder(o);
            }
        }
        api.saveSeen(seen);
        if (first) api.setSeeded();
    }

    /** Pops up a notification (with sound and vibration) for a new order. */
    private void notifyOrder(JSONObject o) {
        try {
            String table = o.optString("table_no", "");
            if ("null".equals(table)) table = "";
            String name = o.optString("customer_name", "");
            if ("null".equals(name)) name = "";
            String title = "New order - " + (!table.isEmpty() ? "Table " + table : "WhatsApp");
            if (!name.isEmpty()) title += " (" + name + ")";

            StringBuilder body = new StringBuilder();
            JSONArray lines = o.optJSONArray("lines");
            if (lines != null) {
                for (int j = 0; j < lines.length(); j++) {
                    if (j > 0) body.append("\n");
                    body.append(String.valueOf(lines.opt(j)).split(" \\| ")[0]);
                }
            }
            String note = o.optString("note", "");
            if (!note.isEmpty() && !"null".equals(note)) body.append("\nNote: ").append(note);

            Intent open = new Intent(this, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
            Notification n = new Notification.Builder(this, CHANNEL_ORDERS)
                    .setContentTitle(title)
                    .setContentText(body.toString().replace("\n", ", "))
                    .setStyle(new Notification.BigTextStyle().bigText(body.toString()))
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            int id = (o.optString("id", "0").hashCode() & 0x7fffffff) + 100;
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(id, n);
        } catch (Exception e) {
            // a notification problem must never stop the voice
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        if (poller != null) poller.interrupt();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
