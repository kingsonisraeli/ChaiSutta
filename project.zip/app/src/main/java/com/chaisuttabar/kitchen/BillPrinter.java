package com.chaisuttabar.kitchen;

import android.app.Activity;
import android.content.Context;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/** Builds the customer bill and opens Android's print screen (printer or Save as PDF). */
final class BillPrinter {
    private static final String SHOP = "Chai Sutta Bar Cafe";
    private static final String ADDR = "Dr. S. Radha Krishnan Park, JNRM College, Sri Vijaya Puram, Andaman &amp; Nicobar Islands";
    private static final String PHONE = "+91 96795 26348";
    private static final String PRICES = "chocolate chai|r=15;chocolate chai|l=25;adrak chai|r=20;adrak chai|l=30;lemon chai|l=30;rose chai|r=30;rose chai|l=40;elaichi chai|r=30;elaichi chai|l=40;paan chai|r=30;paan chai|l=40;kesar chai|r=30;kesar chai|l=40;masala chai|r=30;masala chai|l=40;green chai|l=40;regular hot coffee|r=30;regular hot coffee|l=40;strong hot coffee|r=40;strong hot coffee|l=50;chocolate hot coffee|r=40;chocolate hot coffee|l=50;black hot coffee|r=30;regular cold coffee|=119;strong cold coffee|=129;chocolate cold coffee|=129;cold coffee with ice cream|=139;brownie cold coffee|=149;csb special cold coffee|=159;beer non-alcohol hot coffee|=40;whisky non-alcohol hot coffee|=40;rum non-alcohol hot coffee|=40;vodka non-alcohol hot coffee|=40;brandy non-alcohol hot coffee|=40;red wine non-alcohol hot coffee|=40;beer non-alcohol cold coffee|=119;whisky non-alcohol cold coffee|=119;rum non-alcohol cold coffee|=119;vodka non-alcohol cold coffee|=119;brandy non-alcohol cold coffee|=119;red wine non-alcohol cold coffee|=119;scotch non-alcohol cold coffee|=119;veggie burger|=129;veg cheese burger|=139;veg cheese paneer burger|=149;veg mexican burger|=159;csb special burger|=179;jam sandwich|=69;sev onion sandwich|=99;chocolate sandwich|=99;corn masala sandwich|=109;bombay kaccha sandwich|=109;veggie grilled sandwich|=109;corn mayo sandwich|=109;tandoori sandwich|=119;cheese chutney sandwich|=129;paneer taka tak sandwich|=129;paneer special sandwich|=139;plain maggi|=59;double masala maggi|=69;tandoori maggi|=89;schezwan maggi|=89;corn cheese maggi|=89;vegetable maggi|=89;butter cheese maggi|=99;paneer maggi|=119;csb special maggi|=139;margherita pizza|=179;veggie delight pizza|=199;onion pizza|=199;sweet corn pizza|=219;paneer wrapped pizza|=219;csb special pizza|=279;maska bun|=40;corn chaat|=50;dabeli|=59;moong dal pakoda|=79;garlic bun|=89;cheese garlic bread|=110;pao bhaji|=119;french fries|=119;peri peri fries|=149;cheesy nuggets|=149;extra loaded fries|=179;red sauce pasta|=149;white sauce pasta|=149;mix sauce pasta|=169;strawberry milk shake|=119;vanilla milk shake|=119;butterscotch milk shake|=119;oreo milk shake|=129;kitkat milk shake|=129;dairy milk milk shake|=129;brownie milk shake|=129;black current milk shake|=149;romance candy milk shake|=149;classic mojito|=119;blue lagoon mojito|=119;black cobra mojito|=139;lemon juice|=40;mint lime juice|=50;lemon soda (sweet)|=60;lemon soda (salt)|=60;strawberry masala lemonade|=99;green mint masala lemonade|=99;litchi masala lemonade|=99;pineapple masala lemonade|=99;orange masala lemonade|=99;kiwi masala lemonade|=99;strawberry ice crusher|=89;kiwi ice crusher|=89;blueberry ice crusher|=99;plain ice tea|=119;lemon ice tea|=149";
    private static Map<String, Integer> map;
    private static WebView keep;

    private BillPrinter() {
    }

    private static synchronized Map<String, Integer> prices() {
        if (map == null) {
            map = new HashMap<>();
            for (String p : PRICES.split(";")) {
                int i = p.lastIndexOf('=');
                if (i > 0) map.put(p.substring(0, i), Integer.parseInt(p.substring(i + 1)));
            }
        }
        return map;
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private static String clean(JSONObject o, String k) {
        String v = o.optString(k, "");
        return "null".equals(v) ? "" : v.trim();
    }

    /** Price of one item name such as "Chocolate Chai (R) - Sugar free"; -1 if unknown. */
    private static int priceOf(String name) {
        String[] parts = name.split(" - ");
        String base = parts[0].trim();
        String extra = parts.length > 1 ? parts[1].toLowerCase(Locale.ROOT) : "";
        String size = "";
        if (base.matches("(?i).*\\s\\((R|L)\\)$")) {
            size = base.substring(base.length() - 2, base.length() - 1).toLowerCase(Locale.ROOT);
            base = base.substring(0, base.length() - 4).trim();
        }
        Integer v = prices().get(base.toLowerCase(Locale.ROOT) + "|" + size);
        if (v == null) return -1;
        int p = v;
        if (extra.contains("sugar free")) p += 5;
        if (extra.contains("with cheese")) p += 20;
        return p;
    }

    private static String fmt(String iso, String pattern) {
        try {
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            in.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d = in.parse(iso.substring(0, 19));
            SimpleDateFormat out = new SimpleDateFormat(pattern, Locale.US);
            out.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
            return out.format(d);
        } catch (Exception e) {
            return "";
        }
    }

    /** Bill total of one order: the saved total, or the sum of its item prices. */
    static int totalOf(JSONObject o) {
        int t = o.optInt("total", 0);
        if (t > 0) return t;
        int sum = 0;
        JSONArray lines = o.optJSONArray("lines");
        if (lines == null) return 0;
        for (int j = 0; j < lines.length(); j++) {
            String[] p = String.valueOf(lines.opt(j)).split(" \\| ");
            int qty = 1;
            String nm = p[0];
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\d+)\\s*\u00D7\\s*(.*)$").matcher(p[0]);
            if (m.matches()) {
                qty = Integer.parseInt(m.group(1));
                nm = m.group(2);
            }
            int price = -1;
            if (p.length > 1) {
                try {
                    price = Integer.parseInt(p[1].trim());
                } catch (Exception e) {
                    price = -1;
                }
            }
            if (price < 0) price = priceOf(nm);
            if (price > 0) sum += qty * price;
        }
        return sum;
    }

    static String html(JSONObject o, boolean wide) {
        String w = wide ? "80mm" : "58mm";
        String table = clean(o, "table_no");
        String name = clean(o, "customer_name");
        String phone = clean(o, "phone");
        String note = clean(o, "note");
        String id = o.optString("id", "");
        String created = o.optString("created_at", "");
        StringBuilder rows = new StringBuilder();
        int sum = 0;
        JSONArray lines = o.optJSONArray("lines");
        if (lines != null) {
            for (int j = 0; j < lines.length(); j++) {
                String[] p = String.valueOf(lines.opt(j)).split(" \\| ");
                String t = p[0];
                int qty = 1;
                String nm = t;
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\d+)\\s*\u00D7\\s*(.*)$").matcher(t);
                if (m.matches()) {
                    qty = Integer.parseInt(m.group(1));
                    nm = m.group(2);
                }
                int price = -1;
                if (p.length > 1) {
                    try {
                        price = Integer.parseInt(p[1].trim());
                    } catch (Exception e) {
                        price = -1;
                    }
                }
                if (price < 0) price = priceOf(nm);
                if (price < 0) {
                    rows.append("<div class='r'><b>").append(esc(qty + " x " + nm)).append("</b></div>");
                } else {
                    int amt = qty * price;
                    sum += amt;
                    rows.append("<div class='r'><b>").append(esc(nm)).append("</b><div class='f'><span>")
                            .append(qty).append(" x ").append(price).append("</span><span>")
                            .append(amt).append("</span></div></div>");
                }
            }
        }
        int total = o.optInt("total", 0) > 0 ? o.optInt("total", 0) : sum;
        String billNo = id.length() > 6 ? id.substring(id.length() - 6) : id;
        StringBuilder h = new StringBuilder();
        h.append("<!DOCTYPE html><html><head><meta charset='UTF-8'><style>")
                .append("*{box-sizing:border-box}body{width:").append(w)
                .append(";margin:0;padding:3mm;font-family:monospace;font-size:12px;color:#000}")
                .append(".c{text-align:center}.h{font-size:15px;font-weight:bold}")
                .append(".f{display:flex;justify-content:space-between}")
                .append(".r{margin:4px 0}.hr{border-top:1px dashed #000;margin:6px 0}")
                .append(".t{font-size:15px;font-weight:bold}</style></head><body>")
                .append("<div class='c h'>").append(SHOP).append("</div>")
                .append("<div class='c'>").append(ADDR).append("</div>")
                .append("<div class='c'>Ph: ").append(PHONE).append("</div><div class='hr'></div>")
                .append("<div class='f'><b>Bill No: ").append(esc(billNo)).append("</b><span>")
                .append(fmt(created, "dd/MM/yyyy")).append("</span></div>")
                .append("<div class='f'><span>").append(table.isEmpty() ? "Delivery" : "Dine-in")
                .append("</span><span>").append(fmt(created, "hh:mm a")).append("</span></div>");
        if (!table.isEmpty()) h.append("<div><b>Table No: ").append(esc(table)).append("</b></div>");
        if (!name.isEmpty()) h.append("<div>Name: ").append(esc(name)).append("</div>");
        if (!phone.isEmpty()) h.append("<div>Phone: ").append(esc(phone)).append("</div>");
        h.append("<div class='hr'></div>").append(rows).append("<div class='hr'></div>")
                .append("<div class='f t'><span>TOTAL</span><span>Rs ").append(total).append("</span></div>");
        if (!note.isEmpty()) {
            h.append("<div class='hr'></div><div>").append(table.isEmpty() ? "Address / Note" : "Note")
                    .append(": ").append(esc(note)).append("</div>");
        }
        h.append("<div class='hr'></div><div class='c'>Thank you! Visit again</div>")
                .append("<div class='c'>Since 2022</div></body></html>");
        return h.toString();
    }

    /** Must be called on the main thread. */
    static void print(Activity a, JSONObject o, boolean wide) {
        final String jobName = "Bill " + o.optString("id", "");
        WebView wv = new WebView(a);
        keep = wv;
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                PrintManager pm = (PrintManager) a.getSystemService(Context.PRINT_SERVICE);
                PrintAttributes attrs = new PrintAttributes.Builder()
                        .setMediaSize(new PrintAttributes.MediaSize(wide ? "csb80" : "csb58",
                                wide ? "Receipt 80mm" : "Receipt 58mm", wide ? 3150 : 2283, 11000))
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build();
                pm.print(jobName, view.createPrintDocumentAdapter(jobName), attrs);
            }
        });
        wv.loadDataWithBaseURL(null, html(o, wide), "text/html", "UTF-8", null);
    }
}
